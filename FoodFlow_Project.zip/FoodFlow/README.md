# FoodFlow

Food catering management web application.

## Features
- Online food ordering
- Catering management
- Admin dashboard
- Responsive UI

## Tech Stack
- React
- Node.js
- Express.js
- MongoDB

