function App() {
  return (
    <div>
      <h1>FoodFlow Catering Management</h1>
      <p>Manage catering orders efficiently.</p>
    </div>
  );
}

export default App;
